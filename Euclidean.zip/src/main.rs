//this imports the formula module
mod formula;

fn main() {
    //this allows the formula module to run
    formula::run();
}